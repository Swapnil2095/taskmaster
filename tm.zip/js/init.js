$(document).ready(function() {
  $(".slider").slider();

  $(".scrollspy").scrollSpy({
    scrollOffset: 71
  });
});
