<ul class="sidenav nf" id="mobile-nav">
    <li><a href="#"><img src="img/cancel.png" class="closeb"></a></li>
  <li><a class="white-text" href="../index.php">HOME</a></li>
</ul>
