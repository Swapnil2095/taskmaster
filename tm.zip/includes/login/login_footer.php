<!--footer-->
<footer id="foot">
  <hr style="font-weight: 800">
  <div class="footer-copyright">
    <div class="container center grey-darken-4-text ">
    Copyright © 2018 TaskMaster
    </div>
  </div>
</footer>

</div>
<!-- End flex-container -->

<!-- scripts -->
<script src="js/particles.js"></script>
<script src="js/app.js"></script>
<!-- stats.js -->

<!--additional scripts-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-alpha.4/js/materialize.min.js"></script>
<!-- <script src="js/formanimate.js"></script> -->

<script src="js/login.js"></script>
</body>
</html>
