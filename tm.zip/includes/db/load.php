<?php
require_once('config.php');
require_once('class-db.php');
require_once('random_compat/random.php');
require_once('hash_equals.php');
require_once('class-login.php');
require_once('functions/functions.php');

?>
