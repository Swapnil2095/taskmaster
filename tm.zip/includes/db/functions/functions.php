
<?php

function redirect($location)
{
    header("Location:" . $location);
    exit;
}

function get_user_info($username)
{
      //$results = $login->db->get_results("SELECT * FROM users WHERE username = $username);
}

function add_new_user($post)
{


}










?>
