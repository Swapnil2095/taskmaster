<?php
// Default timezone
date_default_timezone_set('UTC');

// Database details
define( 'DB_USER', 'root' );
define( 'DB_PASS', 'swapnil2095' );
define( 'DB_NAME', 'login_course' );
define( 'DB_HOST', 'localhost' );
define( 'DB_CHARSET', 'utf8mb4');
define( 'ABS_URL', 'https://php-projects-swapnil6195.c9users.io/PHP-Webdevelopment/secure_login_form/advanced/' );
define( 'ADMIN_NAME', 'Swapnil' );
define( 'ADMIN_EMAIL', 'swapnil6195@gmail.com' );
