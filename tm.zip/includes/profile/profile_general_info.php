<div class="row">
<?php
  $login -> get_profile_info($_SESSION['email']);
?>
</div> <!---row-->
