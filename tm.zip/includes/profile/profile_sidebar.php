
<div class="col s12 m12 l4 xl4 white ligthen-4">
        <p class="center upcoming-tasks">Upcoming tasks</p>
    <div class="row side-nav fixed" id="scroll">

      <div id="modal2" class="modal">
              <div class="modal-content">

                <a class="right"><i class="material-icons teal-text icon modal-close">close</i></a>
                <h5>Edit Task</h5>

                <div class="container-fluid">
                  <?php include("profile_form.php") ?>
                </div> <!---container-fluid---->

              </div><!---modal-content---->
      </div><!---modal---->


        <?php include("profile_card.php") ?>




    </div> <!---col s12 m12 l4 xl4 white ligthen-4-->

  </div> <!---row side-nav fixed-->
