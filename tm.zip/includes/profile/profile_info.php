<div class="col s12 m12 l8 xl8">
    <div class="card hoverable">

        <?php include("profile_general_info.php") ?>
        <?php include("profile_addtask.php") ?>

      </div> <!---card hoverable-->
    </div> <!---col s12 m12 l8 xl8-->
