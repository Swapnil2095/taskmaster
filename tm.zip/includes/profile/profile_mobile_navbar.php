<ul class="sidenav grey darken-2" id="mobile-nav">
  <li><a class="white-text" href="../logout.php">Logout</a></li>

</ul>
