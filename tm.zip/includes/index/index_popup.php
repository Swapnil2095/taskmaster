<!-- popup member -->

<div id="modal1" class="modal">
	<div class="modal-content">
      <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat right btn black white-text ">&#10006;</a>
    	<h3 class="center-align text-decoration">MODERATORS</h3>

        <div class="container ">
        	<div class="row">
        	<hr>
          <a href="https://github.com/Swapnil2095" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>SWAPNIL GAIKWAD</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/Rajrox97" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>RITURAJ BASU</h6>
                </div>
             </div>
            </div>
          </a>
            <h3 class="center-align text-decoration">CO-MODS</h3>
            <hr>
            <a href="https://github.com/pbiswas101" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>PRIYABRATA BISWAS</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/omtripathi786" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>OM TRIPATHI</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/Nimmo1993" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>MADHURIMA CHAKRABORTY</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/shashank-sharma" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>SHASHANK SHARMA</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/rayarindam2111" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>ARINDAM RAY</h6>
                </div>
             </div>
            </div>
          </a>

        </div>

        <h3 class="center-align text-decoration">MOST ACTIVE MEMBERS</h3>
        <hr>
        <div class="row">

            <a href="https://github.com/sahkal" target="_blank">
              <div class="col s12 m6 13 center-align">
                <div class="card hovering">
                  <div class="card-content">
                  <h6>SAHKAL PODDAR</h6>
                  </div>
               </div>
              </div>
            </a>

             <a href="https://github.com/Adi-github" target="_blank">
                <div class="col s12 m6 13 center-align">
                  <div class="card hovering">
                    <div class="card-content">
                    <h6>ADITYA SHARMA</h6>
                    </div>
                 </div>
                </div>
             </a>

          <a href="https://github.com/DeepPurohit" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>DEEP PUROHIT</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/souro18" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>SOURAJIT PAUL</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/user501254" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>ANEESH KUMAR SINGH</h6>
                </div>
             </div>
            </div>
          </a>

		   </div>

          <h3 class="center-align text-decoration">SPECIAL THANKS TO!</h3>
          <hr>
       <div class="row">

          <a href="#" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                  <h6>SURYA PRAMOD</h6>
                </div>
              </div>
            </div>
          </a>

          <a href="https://github.com/vattytrivedi" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>VARTSAL TRIVEDI</h6>
                </div>
             </div>
            </div>
          </a>


          <a href="https://github.com/bhaskarSingh" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>BHASKAR SINGH </h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/rampandey06" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>RAM PANDEY </h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/V3dant" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>VEDANT SINGH </h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/abulhayat1" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>ABUL HAYAT </h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/nsaicharan" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>SAI CHARAN</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/amarjeetsingh1999" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>AMARJEET SINGH </h6>
                </div>
             </div>
            </div>
          </a>


          <a href="https://github.com/Abulnoviceninja" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>ABUL HAYAT</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/Suparnapaul393" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>SUPARNA PAUL </h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/RatnadeepBiswakarma" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>RATNADEEP BISWAKARMA </h6>
                </div>
             </div>
            </div>
          </a>

            <a href="https://github.com/yashsartanpara" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>YASH SARTANPARA</h6>
                </div>
             </div>
            </div>
          </a>

          <a href="https://github.com/cTxplorer" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>PRATIK GADHIYA </h6>
                </div>
             </div>
            </div>
          </a>

            <a href="https://github.com/aartigurjar" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                <h6>AARTI GURJAR</h6>
                </div>
              </div>
            </div>
          </a>

          <a href="https://github.com/seethaR03" target="_blank">
            <div class="col s12 m6 13 center-align">
              <div class="card hovering">
                <div class="card-content">
                  <h6>SEETHA </h6>
                </div>
             </div>
            </div>
          </a>

       </div>

   </div>
  </div>
</div>
