<!-- Intro Section -->
<section id="intro" class="center-align  section scrollspy wow fadeInLeft card se" data-wow-delay="0.1s">
    <div class="row">
      <div class="col s12 qw l6"><iframe src="https://www.youtube.com/embed/n3OTWJ4oGAs?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>
      <div class="col s12 m5 wq "><iframe src="https://www.youtube.com/embed/n3OTWJ4oGAs?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div><div class="col s12 fi l6">
        <h2>Introduction</h2>
        <p class="vb">TaskMaster is a one place solution for all your TO-DO Lists and goals in one place.Give color to your goals, attach files, set priorities and do much more. Our website also has an alarm popup feature that will remind you that your time is up to complete a goal.
        </p>
        <p class="vb">This app will help you to take stock of your situation, keep distractions away and focus more on your goals.
        </p>
      </div>

    </div>
</section>
