<ul class="sidenav nf" id="mobile-nav">
    <li><a href="#"><img src="../img/cancel.png" class="sidenav-close closeb"></a></li>
  <li><a class="white-text sidenav-close" href="index.php">HOME</a></li>
  <li><a class="scrollspy white-text sidenav-close" href="#intro">INTRODUCTION</a></li>
  <li><a class="scrollspy white-text sidenav-close" href="#why">WHY TASKMASTER?</a></li>
  <li><a class="scrollspy white-text sidenav-close" href="#csd">CONTACT</a></li>
</ul>
