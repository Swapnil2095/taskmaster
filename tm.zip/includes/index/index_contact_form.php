<!--contact form-->
<section class="Contact black" id="csd">
<div class="container">
<h1 class="center-align white-text wow fadeInDown" data-wow-delay="0.8s">Contact</h1>
<div class="row card-panel hoverable  ">
  <form class="col s12 z-depth-5  white " data-wow-delay="1.2s">
    <br>
    <div class="row ">
      <div class="input-field col col s12 m12 center wow fadeInUp" data-wow-delay="1.3s">
        <i class="material-icons prefix">
          account_circle
        </i>
        <input type="text" class="black-text validate">
        <label class="active" for="firstname ">Full Name</label>
      </div>
      <div class="input-field col s12 m12 center wow fadeInUp"  data-wow-delay="1.3s">
        <i class="material-icons prefix">
          phone
        </i>
        <input type="text" class="black-text validate">
        <label class="active" for="firstname">Phone Number</label>
      </div>
      <div class="input-field col s12 m12 center wow fadeInUp"  data-wow-delay="1.3s">
        <i class="material-icons prefix">
          email
        </i>
        <input type="email" class="black-text validate">
        <label class="active" for="email">Email</label>
      </div>
      <div class=" wow fadeInUp input-field col s12 m12 center" data-wow-delay="1.3s">
            <i class=" material-icons prefix icon-white ">feedback</i>
            <textarea rows="4" id="area" class=" white materialize-textarea" ></textarea>
            <label for="area">Feedback</label>
      </div>
    <div class="row ">
      <div class=" col s12 m12 center ">
    <button class="btn grey darken-3 z-depth-5 center col s12 waves-effect waves-light" id="color">send</button>
      </div>
   </div>
  </form>
</div>
</form>
</div>
</div>
