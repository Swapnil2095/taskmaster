<section id="why" class="center-align section scrollspy wow fadeInRight se card z-depth-1" data-wow-delay="0.1s">
   <div class="container">
     <div class="row">
       <div class="col m6 wc tr col-md-pull-7">
        <h2>Why TaskMaster?</h2>
         <p class="">In this digital age, where almost everything is going for digitization why use traditional TO-DO sticky notes to write down your goals? Our goals are imprinted in our minds if we can visualize them. We have a photo attachment feature exclusively for that purpose. Algorithms are changing every day so that people spend more time on their phones. Let's together conquer our goals with Taskmaster.
        </p>
       </div>
       <div class="col m6 wi tp col-md-push-5"><img src="./img/ss.png"></div>
       <div id="whytab">
        <div id="tab1"><h4>Plan Your Work</h4>Increase Your Productivity<p><img src="./img/productivity.png"></p></div>
        <div id="tab2"><h4>Now Never Forget</h4>Task Master Will Remind You<p><img src="./img/reminder.png"></p></div>
        <div id="tab3"><h4>Goal Tracking</h4>Track Your Progress<p><img src="./img/track.png"></p></div>
       </div>

     </div>
   </div>
</section>
