<!-- navigation bar edited on 12 April,18(@DeepPurohit) -->
<div class="navbar-fixed">
  <nav class="black">
      <!--<div class="nav-wrapper container">
          <a href="#" class="brand-logo">TASKMASTER</a>
          <ul id="nav-mobile" class="right hide-on-med-and-down section table-of-contents">
              <li><a href="index.html">HOME</a></li>
              <li><a class="scrollspy" href="#intro">INTRODUCTION</a></li>
              <li><a class="scrollspy" href="#why">WHY TASKMASTER?</a></li>
          </ul>
      </div>-->
      <div class="nav-wrapper">
        <a href="#" class="brand-logo" id="logo">TASKMASTER</a>
        <a href="#" data-target="mobile-nav" class="sidenav-trigger">
          <i class="material-icons mf">menu</i>
          <ul class="right hide-on-med-and-down">
              <li><a id="nav-links" href="index.php">HOME</a></li>
              <li><a id="nav-links" class="scrollspy" href="#intro">INTRODUCTION</a></li>
              <li><a id="nav-links" class="scrollspy" href="#why">WHY TASKMASTER?</a></li>
              <li><a id="nav-links" class="scrollspy ba" href="#csd">CONTACT</a></li>
          </ul>
        </a>
      </div>
  </nav>
</div>
