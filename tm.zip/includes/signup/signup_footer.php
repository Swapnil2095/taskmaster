<!--- footer-->
<footer>
  <hr style="font-weight: 800">
  <div class="footer-copyright">
    <div class="container center grey-darken-4-text">
    Copyright © 2018 TaskMaster
    </div>
  </div>
</footer>

</div>
<!-- End flex-container -->

<!--scripts -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-alpha.4/js/materialize.min.js"></script>


<!-- custom script edited on 12th April,18(@DeepPurohit) -->
<script src="js/particles.js"></script>
<script src="js/app.js"></script>
<!-- stats.js -->

<script src="js/signup.js"></script>
</body>
</html>
