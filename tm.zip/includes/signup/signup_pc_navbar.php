<div class="navbar-fixed">
  <nav class="black">
      <div class="nav-wrapper">
        <a href="#" class="brand-logo" id="logo">TASKMASTER</a>
        <a href="#" data-target="mobile-nav" class="sidenav-trigger">
          <i class="material-icons">menu</i>
          <ul class="right hide-on-med-and-down">
              <li><a href="../index.php">HOME</a></li>
          </ul>
        </a>
      </div>
  </nav>
</div>
