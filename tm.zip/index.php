<?php include("./includes/index/index_header.php") ?>

<?php include("./includes/index/index_pc_navbar.php") ?>
<?php include("./includes/index/index_mobile_navbar.php") ?>


<!--added image slider web view by @AdityaSharma-->

<?php include("./includes/index/index_mobile_slider.php") ?>

    <div class="test">
      <h3>Tasks Made Easier!</h3>
    </div>

    <div class="tes">
         <a id="start" href="./login.php" class="teal darken-2 waves-effect waves-light btn-large">Get Started</a>
         <div class="arrow">
           <a href="#intro">
             <img src="./img/arrow.svg" class="sc"/>
           </a>
         </div>
    </div>

<?php include("includes/index/index_pc_slider.php") ?>

    <section class="section center wow fadeInUp chl" data-wow-delay="0.2s" style="margin-top: -30px">
        <h5>Tasks Made Easier</h5>
        <a id="start" href="login.php" class="teal waves-effect waves-light btn">Get Started</a>
    </section>


<?php include("includes/index/index_intro.php") ?>

<?php include("includes/index/index_why_tm.php") ?>
<?php include("includes/index/index_contact_form.php") ?>

<?php include("includes/index/index_popup.php") ?>
<?php include("includes/index/index_footer.php") ?>
