<?php include("includes/login/login_header.php") ?>

  <!-- particles.js container -->
  <div id="particles-js"></div>

  <?php include("includes/login/login_pc_navbar.php") ?>
  <?php include("includes/login/login_mobile_navbar.php") ?>


    <div class="flex-container">

      <!--login form code-->
      <section class="center-align login-section">
        <?php include("includes/login/login_form.php") ?>
      </section>

<?php include("includes/login/login_footer.php") ?>
