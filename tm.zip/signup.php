

<?php include("includes/signup/signup_header.php") ?>

    <!-- particles.js container -->
    <div id="particles-js"></div>

    <!--header -->

    <?php include("includes/signup/signup_pc_navbar.php") ?>
    <?php include("includes/signup/signup_mobile_navbar.php") ?>


    <div class="flex-container">

      <!-- registration form -->
      <section class="row signup-section">
        <div class="col offset-s1 s10 offset-m2 m8 offset-l3 l6">
          <div class="row" id="box">
            <div class="col s12">
                <?php include("includes/signup/signup_form.php") ?>
            </div>
          </div>
        </div>
      </section>

<?php include("includes/signup/signup_footer.php") ?>
